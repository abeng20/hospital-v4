<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Signed-in pages live under src/routes/_authenticated/ and read data via the browser client with RLS; roles (admin/hr/staff) live in user_roles and audit_logs is filled by database triggers — keeps permissions enforced server-side.
- Change roles only through the authenticated assign_user_role database function; it checks administrator access and replaces roles atomically to avoid roleless accounts.
- Cloud database setup exports in database/postgresql/ mirror applied migrations in execution order; keep phpMyAdmin schema exports separate in database/mysql/ and document that they do not connect the Cloud app to MySQL.
- Audit triggers shared across different tables must access optional record fields through JSON or table-specific branches to avoid errors on tables without those fields.
- Shared database result handling must throw read errors rather than substitute empty records, and CSV export must escape fields and neutralize formula prefixes to preserve records safely.
