# Hospital Administration, Human Resources & Reporting System

## Where is the database?

The running app stores records in **Lovable Cloud**, not inside the ZIP. Open **View Backend** in Lovable to see database records and registered accounts.

The download includes separately labelled `database/mysql/` and `database/postgresql/` folders. For phpMyAdmin, import only `database/mysql/hospital-phpmyadmin.sql` into a new empty database. PostgreSQL files are for a compatible Cloud backend, not phpMyAdmin. These are structure exports, not live-record or password backups.

**Important:** The website remains connected to Lovable Cloud. Importing the MySQL schema does not create a standalone PHP/MySQL website or switch the website's sign-in and saved records to MySQL. A separate trusted server implementing authentication, permissions and audit logging would still be needed.

## Included modules

- Dashboard: workforce totals, attendance, pending leave and unresolved leaks.
- Employees: search, registration and updates.
- Attendance: record times and status, and correct saved entries.
- Leave: submit requests; administrators and HR approve or reject them.
- Leak Detection: report leaks; administrators and HR update status.
- Reports: view, print and download CSV reports.
- User Management: administrators assign roles atomically.
- Audit Trail: administrators view database-recorded changes and sign-in/sign-out activity.
- Sign in, registration with email confirmation, and sign out.

Staff can view employees, submit and view their own leave requests, and report leaks. Administrators and HR manage employee and attendance records, review leave, update leaks and generate reports. Only administrators manage roles and view audit history. Database permissions enforce these boundaries independently of the menu.

## First administrator

Before sharing the app, register the intended administrator using a real email address, confirm the email, and sign in. The **first registered account becomes administrator**; subsequent accounts become staff. Do not share registration before your administrator is created. Administrators assign HR or administrator roles through User Management.

## Local development

Install Bun, then run:

```sh
bun install
bun run dev
```

Set your own backend public settings in a local `.env`:

```text
VITE_SUPABASE_URL=<backend public URL>
VITE_SUPABASE_PUBLISHABLE_KEY=<backend publishable key>
VITE_SUPABASE_PROJECT_ID=<backend project identifier>
```

Never put database passwords or privileged service keys in these browser settings. No private credentials or live personnel records are included in the download.

For the current project, keep the managed Cloud configuration. A separate compatible Cloud backend needs all three SQL files in `database/postgresql/` applied in order, email/password authentication enabled, and email confirmation enabled. Those files assume that backend supplies `auth.users`, `auth.uid()`, `auth.jwt()` and standard API roles.

## Verification

Routing and CSV/error-handling tests pass. A reproduced audit-trigger failure affecting employee saves was repaired; employee, attendance, leave and leak writes were checked directly in the live database. The phpMyAdmin schema was imported successfully into MariaDB 11.4. Full signed-in workflow verification still requires the first registered and confirmed account. No account or credentials were invented.

## Technology

TanStack Start, React, TypeScript, Tailwind CSS and Lovable Cloud.
