import { describe, expect, it } from "vitest";
import { reportCsv } from "./report-export";
import { requireData } from "./data-result";
describe("Report data", () => {
  it("preserves commas and empty values", () => {
    expect(reportCsv(["Name", "Contact"], [["Vinas, Christianwyn", null]])).toBe('"Name","Contact"\r\n"Vinas, Christianwyn",""');
  });
  it("prevents spreadsheet formulas from running", () => {
    expect(reportCsv(["Name"], [["=1+1"]])).toContain("'=1+1");
  });
  it("reports database failures", () => {
    expect(() => requireData({ data: null, error: { message: "Access denied" } })).toThrow("Access denied");
  });
});
