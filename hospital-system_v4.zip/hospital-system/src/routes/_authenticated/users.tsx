import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { NoAccess, PageHeader } from "@/components/page";
import { useCurrentUser, type AppRole } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/users")({
  head: () => ({ meta: [{ title: "User Management — Hospital Administration" }, { name: "description", content: "Registered hospital accounts and administrator role assignments." }, { property: "og:title", content: "User Management — Hospital Administration" }, { property: "og:description", content: "Registered hospital accounts and administrator role assignments." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Users,
});

const labels: Record<AppRole, string> = { admin: "Administrator", hr: "HR personnel", staff: "Staff" };

function Users() {
  const qc = useQueryClient();
  const { data: me } = useCurrentUser();
  const { data = [] } = useQuery({
    queryKey: ["users"],
    enabled: !!me?.isAdmin,
    queryFn: async () => {
      const [{ data: profiles, error: profilesError }, { data: roles, error: rolesError }] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at"),
        supabase.from("user_roles").select("*"),
      ]);
      if (profilesError) throw profilesError;
      if (rolesError) throw rolesError;
      return (profiles ?? []).map((p) => ({ ...p, role: (roles?.find((r) => r.user_id === p.id)?.role ?? "staff") as AppRole }));
    },
  });

  if (me && !me.isAdmin) return <NoAccess />;

  async function assign(userId: string, role: AppRole) {
    if (userId === me?.id && role !== "admin") { toast.error("You can't remove your own administrator role."); return; }
    const { error } = await supabase.rpc("assign_user_role", { _user_id: userId, _role: role });
    if (error) { toast.error(error.message); return; }
    toast.success("Role updated");
    qc.invalidateQueries({ queryKey: ["users"] });
    qc.invalidateQueries({ queryKey: ["current-user"] });
  }

  return (
    <div>
      <PageHeader title="User Management" subtitle="View registered system accounts and assign roles." />
      <Card>
        <Table>
          <TableHeader><TableRow><TableHead>Email</TableHead><TableHead>Name</TableHead><TableHead>Registered</TableHead><TableHead>Role</TableHead></TableRow></TableHeader>
          <TableBody>
            {data.map((u) => (
              <TableRow key={u.id}>
                <TableCell className="font-medium">{u.email}</TableCell>
                <TableCell>{u.full_name}</TableCell>
                <TableCell className="font-mono text-xs">{new Date(u.created_at).toLocaleDateString()}</TableCell>
                <TableCell>
                  <Select value={u.role} onValueChange={(v) => assign(u.id, v as AppRole)}>
                    <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(labels) as AppRole[]).map((r) => <SelectItem key={r} value={r}>{labels[r]}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
