import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Pencil } from "lucide-react";
import { requireData } from "@/lib/data-result";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/employees")({
  head: () => ({ meta: [{ title: "Employees — Hospital Administration" }, { name: "description", content: "Hospital employee records and department information." }, { property: "og:title", content: "Employees — Hospital Administration" }, { property: "og:description", content: "Hospital employee records and department information." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Employees,
});

type Emp = Tables<"employees">;
const empty = { employee_no: "", first_name: "", last_name: "", department: "", position: "", email: "", contact: "" };
const fields: [keyof typeof empty, string][] = [
  ["employee_no", "Employee no."], ["first_name", "First name"], ["last_name", "Last name"],
  ["department", "Department"], ["position", "Position"], ["email", "Email"], ["contact", "Contact"],
];

function Employees() {
  const qc = useQueryClient();
  const { data: me } = useCurrentUser();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Emp | null>(null);
  const [form, setForm] = useState(empty);
  const [q, setQ] = useState("");

  const { data: rows = [] } = useQuery({
    queryKey: ["employees"],
    queryFn: async () => requireData(await supabase.from("employees").select("*").order("employee_no")) ?? [],
  });

  function openNew() { setEditing(null); setForm(empty); setOpen(true); }
  function openEdit(e: Emp) {
    setEditing(e);
    setForm({ ...empty, ...Object.fromEntries(Object.entries(e).map(([k, v]) => [k, v ?? ""])) } as typeof empty);
    setOpen(true);
  }

  async function save(ev: React.FormEvent) {
    ev.preventDefault();
    const payload = {
      employee_no: form.employee_no, first_name: form.first_name, last_name: form.last_name,
      department: form.department, position: form.position, email: form.email || null, contact: form.contact || null,
    };
    const { error } = editing
      ? await supabase.from("employees").update({ ...payload, updated_at: new Date().toISOString() }).eq("id", editing.id)
      : await supabase.from("employees").insert(payload);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? "Employee updated" : "Employee registered");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["employees"] });
  }

  const filtered = rows.filter((r) =>
    `${r.employee_no} ${r.first_name} ${r.last_name} ${r.department} ${r.position}`.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div>
      <PageHeader
        title="Employee Management"
        subtitle="Register, view and update employee records."
        action={me?.isManager && <Button onClick={openNew}><Plus className="mr-2 h-4 w-4" />Register employee</Button>}
      />
      <Input placeholder="Search employees…" value={q} onChange={(e) => setQ(e.target.value)} className="mb-4 max-w-xs" />
      <Card>
        <Table>
          <TableHeader><TableRow>
            <TableHead>No.</TableHead><TableHead>Name</TableHead><TableHead>Department</TableHead>
            <TableHead>Position</TableHead><TableHead>Email</TableHead><TableHead>Contact</TableHead><TableHead />
          </TableRow></TableHeader>
          <TableBody>
            {filtered.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-mono text-xs">{r.employee_no}</TableCell>
                <TableCell className="font-medium">{r.first_name} {r.last_name}</TableCell>
                <TableCell>{r.department}</TableCell>
                <TableCell>{r.position}</TableCell>
                <TableCell>{r.email}</TableCell>
                <TableCell>{r.contact}</TableCell>
                <TableCell>{me?.isManager && <Button size="icon" variant="ghost" onClick={() => openEdit(r)} aria-label="Edit"><Pencil className="h-4 w-4" /></Button>}</TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && <TableRow><TableCell colSpan={7} className="py-10 text-center text-muted-foreground">No employees yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </Card>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Update employee" : "Register employee"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="grid grid-cols-2 gap-4">
            {fields.map(([k, label]) => (
              <div key={k} className={`space-y-1.5 ${k === "employee_no" ? "col-span-2" : ""}`}>
                <Label htmlFor={k}>{label}</Label>
                <Input id={k} type={k === "email" ? "email" : "text"} value={form[k]} required={k !== "email" && k !== "contact"}
                  onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
              </div>
            ))}
            <Button type="submit" className="col-span-2">Save</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
