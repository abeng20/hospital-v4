import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Printer, Download } from "lucide-react";
import { requireData } from "@/lib/data-result";
import { supabase } from "@/integrations/supabase/client";
import { reportCsv } from "@/lib/report-export";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { NoAccess, PageHeader } from "@/components/page";
import { useCurrentUser, logActivity } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({ meta: [{ title: "Reports — Hospital Administration" }, { name: "description", content: "Hospital workforce, attendance, leave and leak reports." }, { property: "og:title", content: "Reports — Hospital Administration" }, { property: "og:description", content: "Hospital workforce, attendance, leave and leak reports." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Reports,
});

type Kind = "employees" | "attendance" | "leave" | "leaks";
const titles: Record<Kind, string> = {
  employees: "Employee Information Report", attendance: "Attendance Records Report",
  leave: "Leave Applications Report", leaks: "Leak Reports",
};

function Reports() {
  const { data: me } = useCurrentUser();
  const [kind, setKind] = useState<Kind>("employees");

  const { data } = useQuery({
    queryKey: ["report", kind],
    enabled: !!me?.isManager,
    queryFn: async (): Promise<{ head: string[]; rows: (string | null)[][] }> => {
      if (kind === "employees") {
        const d = requireData(await supabase.from("employees").select("*").order("employee_no")) ?? [];
        return { head: ["No.", "Name", "Department", "Position", "Email", "Contact"], rows: d.map((r) => [r.employee_no, `${r.first_name} ${r.last_name}`, r.department, r.position, r.email, r.contact]) };
      }
      if (kind === "attendance") {
        const d = requireData(await supabase.from("attendance").select("*, employees(employee_no, first_name, last_name)").order("date", { ascending: false })) ?? [];
        return { head: ["Date", "Employee", "Time-in", "Time-out", "Status"], rows: d.map((r) => [r.date, r.employees ? `${r.employees.employee_no} ${r.employees.first_name} ${r.employees.last_name}` : "", r.time_in?.slice(0, 5) ?? "", r.time_out?.slice(0, 5) ?? "", r.status]) };
      }
      if (kind === "leave") {
        const d = requireData(await supabase.from("leave_applications").select("*").order("created_at", { ascending: false })) ?? [];
        return { head: ["Applicant", "Type", "Start", "End", "Reason", "Status"], rows: d.map((r) => [r.applicant_email, r.leave_type, r.start_date, r.end_date, r.reason, r.status]) };
      }
      const d = requireData(await supabase.from("leak_reports").select("*").order("created_at", { ascending: false })) ?? [];
      return { head: ["Date", "Location", "Description", "Reporter", "Status"], rows: d.map((r) => [new Date(r.created_at).toLocaleDateString(), r.location, r.description, r.reporter_email, r.status]) };
    },
  });

  if (me && !me.isManager) return <NoAccess />;

  function download() {
    if (!data) return;
    const url = URL.createObjectURL(new Blob(["\uFEFF", reportCsv(data.head, data.rows)], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `hospital-${kind}-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    void logActivity(`Downloaded ${titles[kind]}`, "Reports Generation");
  }

  return (
    <div>
      <PageHeader
        title="Reports Generation"
        subtitle="Generate, view and print reports."
        action={<div className="flex flex-wrap gap-2"><Button variant="outline" disabled={!data} onClick={download}><Download className="mr-2 h-4 w-4" />Download CSV</Button><Button disabled={!data} onClick={() => { logActivity(`Printed ${titles[kind]}`, "Reports Generation"); window.print(); }}><Printer className="mr-2 h-4 w-4" />Print report</Button></div>}
      />
      <Tabs value={kind} onValueChange={(v) => setKind(v as Kind)} className="no-print mb-4">
        <TabsList>
          <TabsTrigger value="employees">Employees</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="leave">Leave</TabsTrigger>
          <TabsTrigger value="leaks">Leaks</TabsTrigger>
        </TabsList>
      </Tabs>
      <Card className="p-6">
        <div className="mb-4 flex items-end justify-between border-b pb-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Hospital Administration, HR &amp; Reporting System</p>
            <h2 className="mt-1 text-2xl">{titles[kind]}</h2>
          </div>
          <p className="font-mono text-xs text-muted-foreground">Generated {new Date().toLocaleString()} · {data?.rows.length ?? 0} records</p>
        </div>
        <Table>
          <TableHeader><TableRow>{data?.head.map((h) => <TableHead key={h}>{h}</TableHead>)}</TableRow></TableHeader>
          <TableBody>
            {data?.rows.map((r, i) => <TableRow key={i}>{r.map((c, j) => <TableCell key={j}>{c ?? ""}</TableCell>)}</TableRow>)}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
