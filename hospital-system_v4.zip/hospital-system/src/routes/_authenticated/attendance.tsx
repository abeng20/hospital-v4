import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Pencil, X } from "lucide-react";
import { toast } from "sonner";
import { requireData } from "@/lib/data-result";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { NoAccess, PageHeader, StatusBadge } from "@/components/page";
import { useCurrentUser } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/attendance")({
  head: () => ({ meta: [{ title: "Attendance — Hospital Administration" }, { name: "description", content: "Employee attendance records, times and corrections." }, { property: "og:title", content: "Attendance — Hospital Administration" }, { property: "og:description", content: "Employee attendance records, times and corrections." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  component: Attendance,
});

function Attendance() {
  const qc = useQueryClient();
  const { data: me } = useCurrentUser();
  const today = new Date().toISOString().slice(0, 10);
  const [f, setF] = useState({ employee_id: "", date: today, time_in: "", time_out: "", status: "present" });

  const [editing, setEditing] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const { data: emps = [] } = useQuery({
    queryKey: ["employees"],
    queryFn: async () => requireData(await supabase.from("employees").select("*").order("employee_no")) ?? [],
  });
  const { data: rows = [] } = useQuery({
    queryKey: ["attendance"],
    enabled: !!me?.isManager,
    queryFn: async () =>
      requireData(await supabase.from("attendance").select("*, employees(employee_no, first_name, last_name)").order("date", { ascending: false }).limit(200)) ?? [],
  });

  if (me && !me.isManager) return <NoAccess />;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!f.employee_id) { toast.error("Select an employee"); return; }
    setBusy(true);
    const payload = { employee_id: f.employee_id, date: f.date, time_in: f.time_in || null, time_out: f.time_out || null, status: f.status };
    const { error } = editing
      ? await supabase.from("attendance").update(payload).eq("id", editing)
      : await supabase.from("attendance").insert(payload);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success(editing ? "Attendance updated" : "Attendance recorded");
    setEditing(null);
    setF({ ...f, time_in: "", time_out: "" });
    qc.invalidateQueries({ queryKey: ["attendance"] });
  }

  return (
    <div>
      <PageHeader title="Attendance Management" subtitle="Record employee time-in, time-out and status." />
      <Card className="mb-6 p-6">
        <form onSubmit={save} className="grid gap-4 md:grid-cols-6">
          <div className="space-y-1.5 md:col-span-2">
            <Label>Employee</Label>
            <Select value={f.employee_id} onValueChange={(v) => setF({ ...f, employee_id: v })}>
              <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
              <SelectContent>
                {emps.map((e) => <SelectItem key={e.id} value={e.id}>{e.employee_no} — {e.first_name} {e.last_name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5"><Label>Date</Label><Input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} required /></div>
          <div className="space-y-1.5"><Label>Time-in</Label><Input type="time" value={f.time_in} onChange={(e) => setF({ ...f, time_in: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Time-out</Label><Input type="time" value={f.time_out} onChange={(e) => setF({ ...f, time_out: e.target.value })} /></div>
          <div className="space-y-1.5">
            <Label>Status</Label>
            <Select value={f.status} onValueChange={(v) => setF({ ...f, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="present">Present</SelectItem><SelectItem value="late">Late</SelectItem>
                <SelectItem value="absent">Absent</SelectItem><SelectItem value="on_leave">On leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2 md:col-span-6 md:justify-self-end">
            {editing && <Button type="button" variant="outline" onClick={() => { setEditing(null); setF({ employee_id: "", date: today, time_in: "", time_out: "", status: "present" }); }}><X className="mr-2 h-4 w-4" />Cancel</Button>}
            <Button type="submit" disabled={busy}>{editing ? "Save correction" : "Record attendance"}</Button>
          </div>
        </form>
      </Card>
      <Card>
        <Table>
          <TableHeader><TableRow><TableHead>Date</TableHead><TableHead>Employee</TableHead><TableHead>Time-in</TableHead><TableHead>Time-out</TableHead><TableHead>Status</TableHead><TableHead /></TableRow></TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="font-mono text-xs">{r.date}</TableCell>
                <TableCell>{r.employees ? `${r.employees.employee_no} — ${r.employees.first_name} ${r.employees.last_name}` : "—"}</TableCell>
                <TableCell>{r.time_in?.slice(0, 5) ?? "—"}</TableCell>
                <TableCell>{r.time_out?.slice(0, 5) ?? "—"}</TableCell>
                <TableCell><StatusBadge value={r.status} /></TableCell>
                <TableCell><Button variant="ghost" size="icon" aria-label="Correct attendance" onClick={() => { setEditing(r.id); setF({ employee_id: r.employee_id, date: r.date, time_in: r.time_in?.slice(0, 5) ?? "", time_out: r.time_out?.slice(0, 5) ?? "", status: r.status }); }}><Pencil className="h-4 w-4" /></Button></TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && <TableRow><TableCell colSpan={6} className="py-10 text-center text-muted-foreground">No attendance records yet.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
