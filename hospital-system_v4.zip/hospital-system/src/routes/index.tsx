import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  ssr: false,
  beforeLoad: () => {
    throw redirect({ to: "/dashboard" });
  },
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Hospital Administration System" },
      { name: "description", content: "Hospital administration, human resources and reporting system." },
      { property: "og:title", content: "Hospital Administration System" },
      { property: "og:description", content: "Hospital administration, human resources and reporting system." },
    ],
  }),
});
