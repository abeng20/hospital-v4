# Database setup

The app's existing database is already running in Lovable Cloud. Open View Backend in Lovable to view it. Nothing needs to be imported for this existing project.

## phpMyAdmin / MySQL

Import only **mysql/hospital-phpmyadmin.sql** into a new empty database. Full click-by-click instructions are in **mysql/README.md**. The import was tested on MariaDB 11.4 and creates seven tables. This schema alone does not connect the included Cloud website to MySQL; a separate authenticated server is still required for a standalone MySQL system.

## Lovable Cloud / PostgreSQL

To recreate the Cloud database in a separate compatible PostgreSQL authentication backend:

1. Apply `postgresql/01-hospital-schema.sql` to a clean database that provides `auth.users`, `auth.uid()`, `auth.jwt()` and roles `anon`, `authenticated` and `service_role`.
2. Apply `postgresql/02-secure-role-management.sql`, then `postgresql/03-fix-audit-trigger.sql`.
3. Enable email/password sign-in and email confirmation in that backend.
4. Configure the app with that backend's public URL and publishable key (see the main README).
5. Register your intended first administrator, confirm their email, and sign in before sharing registration.

Tables: profiles, user_roles, employees, attendance, leave_applications, leak_reports, audit_logs.

In the Cloud/PostgreSQL version, every application table has row-level security and explicit API grants. Record changes are audited through database triggers. Role reassignment checks administrator permission, prevents self-demotion and runs as one transaction. These Cloud security features are not supplied by the MySQL schema.

These SQL files contain structure, not live records, login passwords or database credentials. Never apply them again to the already configured database. Future changes in this Lovable project use the managed migrations, not manual edits to these export copies.
