CREATE TYPE public.app_role AS ENUM ('admin','hr','staff');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
CREATE OR REPLACE FUNCTION public.is_staff_manager(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(_user_id,'admin') OR public.has_role(_user_id,'hr')
$$;

CREATE POLICY "own or admin read profiles" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR public.is_staff_manager(auth.uid()));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY "read own or admin roles" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin insert roles" ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete roles" ON public.user_roles FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'staff');
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_no text NOT NULL UNIQUE,
  first_name text NOT NULL,
  last_name text NOT NULL,
  department text NOT NULL,
  position text NOT NULL,
  email text,
  contact text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.employees TO authenticated;
GRANT ALL ON public.employees TO service_role;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated read employees" ON public.employees FOR SELECT TO authenticated USING (true);
CREATE POLICY "managers write employees" ON public.employees FOR ALL TO authenticated
  USING (public.is_staff_manager(auth.uid())) WITH CHECK (public.is_staff_manager(auth.uid()));

CREATE TABLE public.attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES public.employees(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT current_date,
  time_in time,
  time_out time,
  status text NOT NULL DEFAULT 'present' CHECK (status IN ('present','late','absent','on_leave')),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.attendance TO authenticated;
GRANT ALL ON public.attendance TO service_role;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
CREATE POLICY "managers all attendance" ON public.attendance FOR ALL TO authenticated
  USING (public.is_staff_manager(auth.uid())) WITH CHECK (public.is_staff_manager(auth.uid()));

CREATE TABLE public.leave_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  applicant_email text,
  employee_id uuid REFERENCES public.employees(id) ON DELETE SET NULL,
  leave_type text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (end_date >= start_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.leave_applications TO authenticated;
GRANT ALL ON public.leave_applications TO service_role;
ALTER TABLE public.leave_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own or managers leave" ON public.leave_applications FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff_manager(auth.uid()));
CREATE POLICY "insert own leave" ON public.leave_applications FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND status = 'pending');
CREATE POLICY "managers update leave" ON public.leave_applications FOR UPDATE TO authenticated
  USING (public.is_staff_manager(auth.uid())) WITH CHECK (public.is_staff_manager(auth.uid()));

CREATE TABLE public.leak_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reported_by uuid NOT NULL DEFAULT auth.uid(),
  reporter_email text,
  location text NOT NULL,
  description text NOT NULL,
  status text NOT NULL DEFAULT 'reported' CHECK (status IN ('reported','investigating','resolved')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.leak_reports TO authenticated;
GRANT ALL ON public.leak_reports TO service_role;
ALTER TABLE public.leak_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "authenticated read leaks" ON public.leak_reports FOR SELECT TO authenticated USING (true);
CREATE POLICY "authenticated report leaks" ON public.leak_reports FOR INSERT TO authenticated
  WITH CHECK (reported_by = auth.uid() AND status = 'reported');
CREATE POLICY "managers update leaks" ON public.leak_reports FOR UPDATE TO authenticated
  USING (public.is_staff_manager(auth.uid())) WITH CHECK (public.is_staff_manager(auth.uid()));

CREATE TABLE public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  user_email text,
  action text NOT NULL,
  module text NOT NULL,
  details text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read audit" ON public.audit_logs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.log_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _module text := TG_ARGV[0];
  _details text;
BEGIN
  IF TG_OP = 'DELETE' THEN _details := OLD.id::text; ELSE _details := NEW.id::text; END IF;
  IF TG_OP = 'UPDATE' AND _module IN ('Leave Management','Leak Detection') AND OLD.status IS DISTINCT FROM NEW.status THEN
    _details := 'Status changed to ' || NEW.status;
  END IF;
  INSERT INTO public.audit_logs (user_id, user_email, action, module, details)
  VALUES (auth.uid(), coalesce(auth.jwt()->>'email','system'), TG_OP, _module, _details);
  RETURN NULL;
END $$;

CREATE TRIGGER audit_employees AFTER INSERT OR UPDATE OR DELETE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.log_audit('Employee Management');
CREATE TRIGGER audit_attendance AFTER INSERT OR UPDATE OR DELETE ON public.attendance FOR EACH ROW EXECUTE FUNCTION public.log_audit('Attendance Management');
CREATE TRIGGER audit_leave AFTER INSERT OR UPDATE OR DELETE ON public.leave_applications FOR EACH ROW EXECUTE FUNCTION public.log_audit('Leave Management');
CREATE TRIGGER audit_leaks AFTER INSERT OR UPDATE OR DELETE ON public.leak_reports FOR EACH ROW EXECUTE FUNCTION public.log_audit('Leak Detection');
CREATE TRIGGER audit_roles AFTER INSERT OR DELETE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION public.log_audit('User Management');

CREATE OR REPLACE FUNCTION public.log_activity(_action text, _module text)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  INSERT INTO public.audit_logs (user_id, user_email, action, module)
  VALUES (auth.uid(), coalesce(auth.jwt()->>'email','unknown'), left(_action,100), left(_module,100));
$$;
REVOKE EXECUTE ON FUNCTION public.log_activity(text,text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.log_activity(text,text) TO authenticated;