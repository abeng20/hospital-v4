CREATE OR REPLACE FUNCTION public.log_audit()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _module text := TG_ARGV[0];
  _details text;
  _old jsonb;
  _new jsonb;
BEGIN
  IF TG_OP = 'DELETE' THEN
    _details := to_jsonb(OLD)->>'id';
  ELSE
    _new := to_jsonb(NEW);
    _details := _new->>'id';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF _module IN ('Leave Management','Leak Detection') THEN
      _old := to_jsonb(OLD);
      IF _old->>'status' IS DISTINCT FROM _new->>'status' THEN
        _details := 'Status changed to ' || (_new->>'status');
      END IF;
    END IF;
  END IF;
  INSERT INTO public.audit_logs (user_id, user_email, action, module, details)
  VALUES (auth.uid(), coalesce(auth.jwt()->>'email','system'), TG_OP, _module, _details);
  RETURN NULL;
END $$;