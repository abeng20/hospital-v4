# phpMyAdmin import

1. Open phpMyAdmin and select **New**.
2. Create an empty database named `hospital_system` with `utf8mb4_unicode_ci` collation.
3. Select that database, click **Import**, and choose `hospital-phpmyadmin.sql`.
4. Click **Go**. Seven tables will be created.

Use MySQL 8.0.16 or newer, or MariaDB 10.6 or newer. Import once into an empty database. If tables already exist, use a new empty database rather than deleting existing data. Do not import any files from `database/postgresql/` into phpMyAdmin.

## What this contains

This file creates MySQL versions of the hospital data tables, status options, indexes and relationships. It contains no existing records or passwords. A trusted server must supply UUIDs, attendance dates and verified user IDs when writing records.

## Important connection limit

The included hospital website still runs on Lovable Cloud. Importing this file does **not** switch its sign-in or saved records to MySQL. This is a compatible schema for a separate MySQL deployment, not a complete standalone PHP/MySQL system.

MySQL does not provide the Cloud authentication, row-level permissions, role-assignment functions or actor-aware audit triggers. These must be implemented and verified by a trusted application server before using MySQL for real personnel records. No working MySQL login/backend is included. Do not disable permissions or expose database credentials in the browser.